<?php
global $em_bodytypes;
$em_bodytypes = array();
$em_bodytypes['1'] = '匀称';
$em_bodytypes['2'] = '苗条';
$em_bodytypes['3'] = '健壮';
$em_bodytypes['4'] = '略胖';
$em_bodytypes['5'] = '丰满';
$em_bodytypes['6'] = '瘦小';
$em_bodytypes['7'] = '高瘦';
?>